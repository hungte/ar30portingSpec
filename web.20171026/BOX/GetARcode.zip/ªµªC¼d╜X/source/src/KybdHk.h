#ifndef _KEYHOOK_WRAPPER__
#define _KEYHOOK_WRAPPER__
#include <windows.h>
#include <windowsx.h>
#include <tchar.h>
#endif

#ifdef BUILD_DLL
#define _KEYHOOKEXPORT __declspec(dllexport)
#elif defined(__cplusplus)
#define _KEYHOOKEXPORT extern "C" __declspec(dllimport)
#else
#define _KEYHOOKEXPORT __declspec(dllimport)
#endif

_KEYHOOKEXPORT BOOL WINAPI installhook (HWND hwnd, UINT message);
_KEYHOOKEXPORT BOOL WINAPI removehook ();
